import './Classe.css';
import Card from '../Card';

const Classe = (props) => {
    const css = { backgroundColor: props.corSecundaria }
    return(
        (props.aventureiros.length > 0) ? 
            <section className='time' style={css}>
                <h3 style={{borderColor: props.corPrimaria}}>{props.nome}</h3>
                {props.aventureiros.map( aventureiro => <Card nome={aventureiro.nome} cargo={aventureiro.cargo} imagem={aventureiro.imagem}/> )}
            </section>: ''
    )
}

export default Classe;